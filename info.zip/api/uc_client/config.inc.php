<?php
//define('UC_CONNECT', 'mysql');
define('UC_CONNECT', '');

