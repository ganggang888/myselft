<?php
namespace Common\Service;
interface InfoService
{
	public function index(); //修改默认成长册首页
	public function edit(); //修改默认成长册
	public function edit_post(); //提交修改默认成长册
}