<?php
interface InfoService
{
	public function getCourse($id);
}