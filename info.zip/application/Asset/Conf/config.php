<?php
return  array(
		//'TMPL_ACTION_ERROR' 	=> C("SP_ADMIN_TMPL_PATH").C("SP_ADMIN_DEFAULT_THEME").'/Admin/error.html', // 默认错误跳转对应的模板文件
		//'TMPL_ACTION_SUCCESS' 	=> C("SP_ADMIN_TMPL_PATH").C("SP_ADMIN_DEFAULT_THEME").'/Admin/success.html', // 默认成功跳转对应的模板文件
);

