<?php
return array(
		"List/nav_index",
		"Page/nav_index",
);