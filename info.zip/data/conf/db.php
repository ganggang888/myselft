<?php

/**
 * 配置文件
 */
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'matt_chat',
    'DB_USER' => 'root',
    'DB_PWD' => '111111',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'sp_',
    //密钥
    "AUTHCODE" => 'cOrdkpMYZ8JyzLje3f',
    //cookies
    "COOKIE_PREFIX" => 'XPiqQM_',
);
?>