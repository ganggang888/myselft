<?php	return array (
  'SP_DEFAULT_THEME' => 'simplebootx',
  'DEFAULT_THEME' => 'simplebootx',
  'SP_ADMIN_STYLE' => 'bluesky',
  'URL_MODEL' => '0',
  'URL_HTML_SUFFIX' => '',
  'UCENTER_ENABLED' => 0,
  'COMMENT_NEED_CHECK' => 0,
  'COMMENT_TIME_INTERVAL' => 60,
  'MOBILE_TPL_ENABLED' => 0,
  'HTML_CACHE_ON' => false,
);?>